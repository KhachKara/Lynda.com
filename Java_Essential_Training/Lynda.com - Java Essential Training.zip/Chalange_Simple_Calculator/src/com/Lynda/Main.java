package com.Lynda;

import java.io.InputStream;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a first numeric value ");
        int val1 = scanner.nextInt();
        System.out.print("Enter a second numeric value ");
        float val2 = scanner.nextFloat();
        float result = val1 + val2;
        System.out.print("The result = " + result);
    }
}
