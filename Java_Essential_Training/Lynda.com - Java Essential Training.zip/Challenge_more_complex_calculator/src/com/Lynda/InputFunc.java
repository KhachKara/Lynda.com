import java.util.Scanner;

public class InputFunc
{
    private String getInput(String prompt){
            System.out.print(prompt);
            Scanner sc = new Scanner(System.in);
            return sc.nextLine();
        }
}
