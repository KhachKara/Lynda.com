import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        boolean boolVal = true;
        while (boolVal) {
            Scanner sc = null;
            double num1 = 0;
            double num2 = 0;
            String operation = null;
            try {
                sc = new Scanner(System.in);
                System.out.print("Введите первое число: ");
                num1 = sc.nextDouble();
                System.out.print("Введите второе число: ");
                num2 = sc.nextDouble();
                System.out.print("Выберите операцию (+, -, *, /): ");
                operation = new String(sc.next());

            double result = 0;

            switch (operation) {
                case "+":
                    result = num1 + num2;
                    break;
                case "-":
                    result = num1 - num2;
                    break;
                case "*":
                    result = num1 * num2;
                    break;
                case "/":
                    result = num1 / num2;
                    break;
                default:
                    System.out.println("Не понятная операция.");
                    break;
            }
            System.out.println("Результат: " + result);
            System.out.print("Если хотите завершить нажмите 0: " + "\n" +
                    "Если хотите продолжить нажмите любое число: ");
            int finish = sc.nextInt();
            if (finish == 0){
                boolVal = false;
            }else {
                System.out.println("Продолжаем.");
            }
            } catch (InputMismatchException e) {
                System.out.println("Введите корректное значение");
            }

            }
        }
    }
