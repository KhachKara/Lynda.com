package com.Lynda;

import util.Math_func;
import java.util.Scanner;

public class Main_2 {

    public static void main(String[] args) {
        Main_2 calc = new Main_2();
        calc.Calculate();
    }

    private void Calculate() {
        InputFunc input_func = new InputFunc();
        String s1 = input_func.getInput("Введите цифровое значение: ");
        String s2 = input_func.getInput("Введите цифровое значение: ");
        String op = input_func.getInput("Выберите операцию (+, -, *, /): ");

        double result = 0;
        try {
            switch (op){
                case "+":
                    result = Math_func.addValues(s1, s2);
                    break;
                case "-":
                    result = Math_func.subtractValues(s1, s2);
                    break;
                case "*":
                    result = Math_func.multiplValues(s1, s2);
                    break;
                case "/":
                    result = Math_func.divideValues(s1, s2);
                    break;
                    default:
                        System.out.println("Не опозненная операция");
                        return;
                }
            System.out.println("Результат: " + result);
        } catch (Exception e){
            System.out.println("Исключение формаьтирования цифр"
            + e.getMessage());
        }
    }

    class InputFunc {
        private String getInput(String prompt){
            System.out.print(prompt);
            Scanner sc = new Scanner(System.in);
            return sc.nextLine();
        }
    }


}