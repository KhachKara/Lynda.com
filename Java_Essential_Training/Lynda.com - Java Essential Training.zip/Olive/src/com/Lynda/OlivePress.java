package com.Lynda;

import com.Lynda.model.Olive;
import java.util.List;

public class OlivePress {
    public int getOil(List<Olive> olives){
        int res = 0;
        int quan = 0;
        for (Olive o : olives){
            res += o.getOil();
            System.out.println(o.getName());
             quan ++;
        }
        System.out.println("Было выжато: " + quan + " оливок.");
        return res;
    }
}
